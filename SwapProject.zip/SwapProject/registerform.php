<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Registration</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #fff;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .registration-container {
            background: #444;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.5);
            width: 300px;
            text-align: center;  
        }

        .registration-container h2 {
            color: #fff;
            margin-bottom: 20px;
        }

        .registration-form input[type="text"],
        .registration-form input[type="password"],
        .registration-form input[type="email"],
        .registration-form input[type="tel"],
        .registration-form button,
        .back-link {
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #555;
            border-radius: 5px;
            background: #fff;
            width: 100%; 
            box-sizing: border-box; 
        }

        .registration-form button {
            background: #5cb85c;
            color: white;
            font-weight: bold;
            cursor: pointer;
            transition: background 0.3s ease;
            border: none; 
            margin-top: 20px; 
        }

        .registration-form button:hover {
            background: #4cae4c;
        }

        .back-link {
            color: #ccc;
            display: block;
            text-decoration: none;
            font-weight: bold;
            transition: color 0.3s ease;
            margin-top: 20px; 
            background: none; 
            border: none; 
        }

        .back-link:hover {
            color: #fff;
            text-decoration: underline;
        }
   
</style>
</head>
<body>
<div class="registration-container">
    <h2>User Registration</h2>
    <form class="registration-form" action="register.php" method="post">
        <input type="text" name="name" placeholder="Name" required>
        <input type="text" name="username" placeholder="Username" required>
        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Password" required>
        <input type="password" name="confirm_password" placeholder="Confirm Password" required>
        <input type="tel" name="contact" placeholder="Contact Number" required>
        <input type="text" name="address" placeholder="Address" required>
        <button type="submit">Register</button>
    </form>
    <a href="loginform.php" class="back-link">Back to Login</a>
</div>
</body>
</html>