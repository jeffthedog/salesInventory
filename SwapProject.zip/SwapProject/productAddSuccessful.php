<?php
echo "Item added successfully.";
?>

<script>
    // Delay for 5 seconds (5000 milliseconds) and then redirect
    setTimeout(function () {
        window.location.href = 'admin_home.php';
    }, 5000);
</script>
