<?php
@session_start();
require_once"database.php";
require_once "auth.php";
// Check if the user is logged in
redirectToLogin();

// Check if the user has admin privileges
redirectToAccessDenied();

// Fetch data from the database
$query = "SELECT item.ITEM_NAME, SUM(transaction_items.QUANTITY) AS total_sales
          FROM transaction_items
          JOIN item ON transaction_items.ITEM_SELECTED = item.ID
          GROUP BY transaction_items.ITEM_SELECTED
          ORDER BY total_sales DESC";

$result = mysqli_query($con, $query);

// Process the result into arrays for Chart.js
$labels = [];
$data = [];

while ($row = mysqli_fetch_assoc($result)) {
    $labels[] = $row['ITEM_NAME'];
    $data[] = $row['total_sales'];
}

// Close the database connection if needed

?>

<style>
    body {
        font-family: Arial, sans-serif;
    }
    .header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 20px;
    }
    .nav {
        list-style-type: none;
        display: flex;
        gap: 20px;
    }
    .nav li {
        display: inline;
    }
    .search-bar {
        display: flex;
        gap: 10px;
    }
    .search-bar input {
        padding: 5px;
    }
    .sidebar {
        float: left;
        width: 20%;
        height: 100vh;
        background-color: #f0f0f0;
        padding: 20px;
    }
    .content {
        float: right;
        width: 80%;
        height: 100vh;
        background-color: #fff;
        padding: 20px;
    }
    .sidebar ul {
        list-style-type: none;
        padding: 0;
    }
    .sidebar li {
        margin-bottom: 10px;
        cursor: pointer; /* Add this line to make the items clickable */
    }
    /* Clear floats after the columns */
    .row:after {
        content: "";
        display: table;
        clear: both;
    }

</style>

<?=admin_header('Admin_Home')?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sales Chart</title>
    <!-- Include Chart.js library -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="row">
        <div class="sidebar">
            <ul>
                <li><a href="sales_chart.php">Sales</a></li>
            	<li><a href="transactions.php">Transactions</a></li>
                <li><a href="usermanagement.php">Users</a></li>
                <li><a href="admin_home.php">Products</a></li>
            </ul>
        </div>
        <div class="content">
            <div style="width: 80%; margin: auto;">
                <canvas id="salesChart"></canvas>
            </div>
        </div>
    </div>
<body>



<script>
    // Create a bar chart
    var ctx = document.getElementById('salesChart').getContext('2d');
    var myChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($labels); ?>,
            datasets: [{
                label: 'Total Sales',
                data: <?php echo json_encode($data); ?>,
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
</script>

</body>
</html>
