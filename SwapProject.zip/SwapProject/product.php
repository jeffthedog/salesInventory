<?php
@session_start();

if (isset($_GET['id'])) {
    // Prepare statement and execute, prevents SQL injection
    $stmt = $con->prepare('SELECT * FROM item WHERE id = ?');
    $stmt->bind_param('i', $_GET['id']);
    $stmt->execute();
    // Get the result set from the query
    $result = $stmt->get_result();
    // Fetch the product from the result set and return the result as an array
    $product = $result->fetch_assoc();
    // Check if the product exists (array is not empty)
    if (!$product) {
        // Simple error to display if the id for the product doesn't exist (array is empty)
        exit('Product does not exist!');
    }
    // Close the result set
    $result->close();
    // Close the statement
    $stmt->close();
} else {
    // Simple error to display if the id wasn't specified
    exit('Product not specified!');
}
?>

<?=website_header('Product')?>

<div class="product content-wrapper">
    <img src="<?=$product['IMAGE']?>" width="500" height="500" alt="<?=$product['ITEM_NAME']?>">
    <div>
        <h1 class="name"><?=$product['ITEM_NAME']?></h1>
        <span class="price">
            &dollar;<?=$product['ITEM_PRICE']?>
        </span>
        <form action="index.php?page=cart" method="post">
            <input type="number" name="quantity" value="1" min="1" max="<?=$product['STOCK']?>" placeholder="Quantity" required>
            <input type="hidden" name="product_id" value="<?=$product['ID']?>">
            <input type="submit" value="Add To Cart">
        </form>
        <div class="description">
            <?=$product['DESCRIPTION']?>
        </div>
    </div>
</div>

<?=website_footer()?>
