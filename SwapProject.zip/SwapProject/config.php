<?php
//database connection
$db_hostname="localhost";
$db_username="root";
$db_password="";

$db_database="swap";


?>