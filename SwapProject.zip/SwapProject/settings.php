<?php
include 'database.php'; // Replace with the path to your database connection file
session_start(); // Start the session

// Function to get user details
function getUserDetails($username, $con) {
    $stmt = $con->prepare("SELECT NAME, USERNAME, EMAIL, CONTACT FROM user WHERE USERNAME = ?");
    if (!$stmt) {
        throw new Exception("Prepare failed: " . $con->error);
    }
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

// Function to update user details
function updateUser($username, $new_name, $new_email, $new_contact, $con) {
    $update_query = "UPDATE user SET ";
    $updates = array();
    $params = array();

    if (!empty($new_name)) {
        $updates[] = "NAME = ?";
        $params[] = $new_name;
    }
    if (!empty($new_email)) {
        $updates[] = "EMAIL = ?";
        $params[] = $new_email;
    }
    if (!empty($new_contact)) {
        $updates[] = "CONTACT = ?";
        $params[] = $new_contact;
    }

    if (count($updates) === 0) {
        // No updates, return early
        return false;
    }

    $update_query .= implode(", ", $updates) . " WHERE USERNAME = ?";
    $params[] = $username; // Add the username to the end of the params array for the WHERE clause

    $stmt = $con->prepare($update_query);
    if (!$stmt) {
        throw new Exception("Prepare failed: " . $con->error);
    }

    $stmt->bind_param(str_repeat("s", count($params)), ...$params);
    return $stmt->execute();
}

// Function to delete user
function deleteUser($username, $con) {
    $stmt = $con->prepare("DELETE FROM user WHERE USERNAME = ?");
    if (!$stmt) {
        throw new Exception("Prepare failed: " . $con->error);
    }
    $stmt->bind_param("s", $username);
    $result = $stmt->execute();
    if (!$result) {
        throw new Exception("Execute failed: " . $stmt->error);
    }
    return $result;
}

// If form is submitted, process the form data
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Update user details
    if (isset($_POST['change_details'])) {
        $new_name = trim($_POST['new_name']);
        $new_email = trim($_POST['new_email']);
        $new_contact = trim($_POST['new_contact']);
        
        if (updateUser($_SESSION['username'], $new_name, $new_email, $new_contact, $con)) {
            // Update successful, update session variable if the name was changed
            if (!empty($new_name)) {
                $_SESSION['name'] = $new_name;
            }
            header("location: settings.php"); // Redirect to the settings page
            exit;
        } else {
            // Update failed, handle error
            $error_message = "Error updating record: " . $con->error;
        }
    }
    // Delete user
    elseif (isset($_POST['delete'])) {
        try {
            if (deleteUser($_SESSION['username'], $con)) {
                // Deletion successful
                $_SESSION = array(); // Clear the session array
                session_destroy(); // Destroy the session
                header("location: loginform.php"); // Redirect to the login page
                exit;
            }
        } catch (Exception $e) {
            $error_message = "Error deleting record: " . $e->getMessage();
        }
    }
}

// Fetch user details
if (isset($_SESSION['username'])) {
    $userDetails = getUserDetails($_SESSION['username'], $con);
} else {
    // No user is logged in, redirect to login page or handle accordingly
    header("location: loginform.php");
    exit;
}

// HTML and form code here (omitted for brevity)
?>


<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Account Settings</title>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
    <style>
      /* Reset some basic elements */
body, h1, h2, h3, p, form, input, select, button {
  margin: 0;
  padding: 0;
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

/* Use a consistent background */
body {
  background-color: #f4f4f7;
  color: #333;
  line-height: 1.6;
}

/* Style the container for the settings */
.settings-container {
  max-width: 1000px;
  margin: 30px auto;
  padding: 20px;
  background: #fff;
  border-radius: 8px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

/* Style headings */
h1 {
  font-size: 24px;
  color: #333;
  padding-bottom: 10px;
  margin-bottom: 20px;
  border-bottom: 1px solid #eaeaea;
}

/* Style the form elements */
input[type="text"],
input[type="email"],
select {
  width: 100%;
  padding: 10px;
  margin-bottom: 20px;
  border: 1px solid #ccc;
  border-radius: 4px;
}

/* Style the buttons */
button {
  background-color: #5cb85c; /* Green color */
  color: white;
  padding: 10px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 16px;
}

button:hover {
  background-color: #4cae4c; /* Darker green */
}

/* Add some spacing to sections */
.section {
  margin-bottom: 20px;
}

/* Profile image styles */
.profile-image {
  width: 150px;
  height: 150px;
  background-color: #ddd;
  border-radius: 50%;
  margin: 20px auto;
  display: block;
}

/* Tabs for different settings sections */
.tab {
  display: inline-block;
  margin-right: 10px;
  padding: 10px;
  border: none;
  background: #eaeaea;
  color: #333;
  border-radius: 4px;
  text-decoration: none;
  font-size: 16px;
  transition: background-color 0.3s;
}

.tab:hover {
  background-color: #ddd;
}

/* Active tab style */
.tab.active {
  background-color: #333;
  color: white;
}

/* Responsive design */
@media (max-width: 768px) {
  .settings-container {
    margin: 10px;
  }
}
      
    </style>
</head>
<body>
    <div class="settings-container">
        <div class="sidebar">
            <a href="help.php">Help</a>
            <a href="logout.php">Logout</a>
        </div>
        <div class="main-content">
            <div class="user-info">
                <!-- Placeholder image source -->
                <img src="https://via.placeholder.com/150" alt="Profile Picture">
                <h2><?php echo htmlspecialchars($userDetails['NAME']); ?></h2>
                <p><?php echo htmlspecialchars($userDetails['USERNAME']); ?></p>
                <p><?php echo htmlspecialchars($userDetails['EMAIL']); ?></p>
                <p><?php echo htmlspecialchars($userDetails['CONTACT']); ?></p>
            </div>
            <div class="form-container">
                <h2>Edit Details</h2>
                <!-- Change details form -->
                <form method="post">
                    <input type="text" name="new_name" placeholder="Change name">
                    <input type="email" name="new_email" placeholder="Change email">
                    <input type="tel" name="new_contact" placeholder="Change contact">
                    <input type="submit" name="change_details" value="Update Details">
                </form>
                <!-- Delete account form -->
                <form method="post">
                    <input type="submit" name="delete" value="Delete Account" onclick="return confirm('Are you sure you want to delete your account?');">
                </form>
            </div>
        </div>
    </div>
</body>
</html>
