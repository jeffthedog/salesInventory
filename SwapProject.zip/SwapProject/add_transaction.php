<?php
include 'database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve and sanitize form data
    $transaction_total = sanitizeInput($_POST['transaction_total']);
    $date = sanitizeInput($_POST['date']);
    $description = sanitizeInput($_POST['description']);
    $user = sanitizeInput($_POST['user']);

    
    // Insert the new transaction into the transaction table
    $insertTransactionQuery = 'INSERT INTO transaction (TRANSACTION_TOTAL, DATE, DESCRIPTION, USER) VALUES (?, ?, ?, ?)';
    $stmtTransaction = $con->prepare($insertTransactionQuery);
    $stmtTransaction->bind_param('dssi', $transaction_total, $date, $description, $user);
    
    if ($stmtTransaction->execute()) {
        // Display a success message using JavaScript
        echo '<script>';
        echo 'document.addEventListener("DOMContentLoaded", function() {';
        echo '    var popupMessage = "Transaction created successfully!";';
        echo '    alert(popupMessage);';
        echo '});';
        echo '</script>';
    } else {
        // Display an error message using JavaScript
        echo '<script>';
        echo 'document.addEventListener("DOMContentLoaded", function() {';
        echo '    var popupMessage = "Error creating transaction: ' . $stmtTransaction->error . '";';
        echo '    alert(popupMessage);';
        echo '});';
        echo '</script>';
    }
    
    $stmtTransaction->close();
}

// Function to sanitize user input
function sanitizeInput($input) {
    return htmlspecialchars(strip_tags(trim($input)), ENT_QUOTES, 'UTF-8');
}
?>
