<?php

// slideshow image URLs
$hardcodedImages = [
    'https://www.ruthvens.com/wp-content/uploads/2019/02/iStock-469925812-1024x683.jpg',
    'https://onestopretrofit.com/wp-content/uploads/2019/03/construction-services-e1554652762765.jpg',
    'https://canberradiamondblade.com.au/wp-content/uploads/2019/02/construction-safety-equipment-.jpeg',
    // Add more image URLs as needed
];
// Assuming $con is a valid MySQLi connection
$stmt = $con->prepare('SELECT * FROM item ORDER BY ID ASC LIMIT 3');
$stmt->execute();

// Binding result variables
$stmt->bind_result($id, $item_name, $item_price, $stock, $description, $specification, $image);

// Fetching results into an array
$products = array();

while ($stmt->fetch()) {
    $product = array(
        'ID' => $id,
        'ITEM_NAME' => $item_name,
        'ITEM_PRICE' => $item_price,
        'IMAGE' => $image,
        // Add more columns as needed
    );
    $products[] = $product;
}

// Close the statement
$stmt->close();
?>
<style>  
    /* Add this style to remove white space */  
    body, html {  
        margin: 0;  
        padding: 0;  
    }  
    .carousel-container {  
        overflow: hidden;  
    }  
    .carousel {  
        display: flex;  
        transition: transform 1s ease;  
    }  
    .carousel-item {  
        width: 100%;  
    }  
</style>  
  
<?=website_header('Home')?>  
<div class="carousel-container">  
    <div class="carousel">  
        <?php foreach ($hardcodedImages as $imageURL): ?>  
            <div class="carousel-item">  
                <a href="#" class="product">  
                    <!-- Hardcoded image -->  
                    <img src="<?= $imageURL ?>" width="1560", height="800" alt="Hardcoded Image">  
                </a>  
            </div>  
        <?php endforeach; ?>  
    </div>  
</div>  
 
<div class="recentlyadded content-wrapper">  
    <h2>Recently Added Products</h2>  
    <div class="products">  
        <?php foreach ($products as $product): ?>  
        <a href="index.php?page=product&id=<?=$product['ID']?>" class="product">  
            <img src="<?=$product['IMAGE']?>" width="200" height="200" alt="<?=$product['ITEM_NAME']?>">  
            <span class="name"><?=$product['ITEM_NAME']?></span>  
            <span class="price">  
                &dollar;<?=$product['ITEM_PRICE']?>  
            </span>  
        </a>  
        <?php endforeach; ?>  
    </div>  
</div>  
  
<?=website_footer()?>  
  
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>  
<script>  
    $(document).ready(function () {  
        var currentIndex = 0;  
        var items = $('.carousel-item');  
        var totalItems = items.length;  
  
        function showNextProduct() {  
            currentIndex = (currentIndex + 1) % totalItems;  
            var translateValue = -currentIndex * 100 + '%';  
            $('.carousel').css('transform', 'translateX(' + translateValue + ')');  
        }  
  
        setInterval(showNextProduct, 3000); // Change product every 3 seconds  
    });  
</script>