<?php
@session_start();
require_once "database.php";
require_once "auth.php";

// Check if the user is logged in
redirectToLogin();

// Check if the user has admin privileges
redirectToAccessDenied();

?>

    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
            background-color: #333;
            color: #fff;
        }

        .nav {
            list-style-type: none;
            display: flex;
            gap: 20px;
        }

        .nav li {
            display: inline;
        }

        .search-bar {
            display: flex;
            gap: 10px;
        }

        .search-bar input {
            padding: 5px;
        }

        .sidebar {
            float: left;
            width: 20%;
            height: 100vh;
            background-color: #f0f0f0;
            padding: 20px;
        }

        .content {
            float: right;
            width: 80%;
            height: 100vh;
            background-color: #fff;
            padding: 20px;
        }

        .sidebar ul {
            list-style-type: none;
            padding: 0;
        }

        .sidebar li {
            margin-bottom: 10px;
            cursor: pointer; /* Add this line to make the items clickable */
        }


        .chart-container {
            width: 48%;
            margin-bottom: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden;
        }

        h2 {
            text-align: center;
            padding: 10px;
            background-color: #3498db;
            color: #fff;
            margin: 0;
        }

        canvas {
            width: 100%;
            height: auto;
        }
    </style>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<?=admin_header('Admin_Home')?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sales Chart</title>
    <!-- Include Chart.js library -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="row">
        <div class="sidebar">
            <ul>
                <li><a href="sales_chart.php">Sales</a></li>
            	<li><a href="transactions.php">Transactions</a></li>
                <li><a href="usermanagement.php">Users</a></li>
                <li><a href="admin_home.php">Products</a></li>
            </ul>
        </div>
        <div class="content">
            <div style="width: 80%; margin: auto;">
                    <?php

                        // Bar Chart
                        $sqlBar = "SELECT ITEM_NAME, STOCK FROM item";
                        $resultBar = $con->query($sqlBar);
                    
                        if ($resultBar->num_rows > 0) {
                            $labelsBar = [];
                            $dataBar = [];
                    
                            while ($rowBar = $resultBar->fetch_assoc()) {
                                $labelsBar[] = $rowBar['ITEM_NAME'];
                                $dataBar[] = $rowBar['STOCK'];
                            }
                    
                            echo '<div class="chart-container" style="width: 100%;">'; // Adjusted width
                            echo '<h2>Stock Levels</h2>';
                            echo '<canvas class="itemChart"></canvas>';
                            echo '</div>';
                    
                            echo '<script>';
                            echo 'var ctxBar = document.querySelector(".itemChart").getContext("2d");';
                            echo 'var myChartBar = new Chart(ctxBar, {';
                            echo 'type: "bar",';
                            echo 'data: {';
                            echo 'labels: ' . json_encode($labelsBar) . ',';
                            echo 'datasets: [{';
                            echo 'label: "Stock",';
                            echo 'data: ' . json_encode($dataBar) . ',';
                            echo 'backgroundColor: "steelblue",';
                            echo '}],';
                            echo '},';
                            echo 'options: {';
                            echo 'scales: {';
                            echo 'y: {';
                            echo 'beginAtZero: true,';
                            echo '},';
                            echo '},';
                            echo '},';
                            echo '});';
                            echo '</script>';
                        } else {
                            echo "<p>0 results for bar chart</p>";
                        }
                    
                        // Pie Chart
                        $sqlPie = "SELECT ITEM_NAME, ITEM_PRICE FROM item";
                        $resultPie = $con->query($sqlPie);
                    
                        if ($resultPie->num_rows > 0) {
                            $labelsPie = [];
                            $dataPie = [];
                    
                            while ($rowPie = $resultPie->fetch_assoc()) {
                                $labelsPie[] = $rowPie['ITEM_NAME'];
                                $dataPie[] = $rowPie['ITEM_PRICE'];
                            }
                    
                            echo '<div class="chart-container" style="width:50%;">'; // Adjusted width
                            echo '<h2>Item Prices</h2>';
                            echo '<canvas class="priceChart"></canvas>';
                            echo '</div>';
                    
                            echo '<script>';
                            echo 'var ctxPie = document.querySelector(".priceChart").getContext("2d");';
                            echo 'var myChartPie = new Chart(ctxPie, {';
                            echo 'type: "pie",';
                            echo 'data: {';
                            echo 'labels: ' . json_encode($labelsPie) . ',';
                            echo 'datasets: [{';
                            echo 'data: ' . json_encode($dataPie) . ',';
                            echo 'backgroundColor: [';
                            echo '"#3498db", "#2ecc71", "#e74c3c", "#f39c12", "#9b59b6", "#34495e", "#1abc9c", "#e67e22"';
                            echo ']';
                            echo '}],';
                            echo '},';
                            echo '});';
                            echo '</script>';
                        } else {
                            echo "<p>0 results for pie chart</p>";
                        }
                    
                        $con->close();
                        ?>
            </div>
        </div>
    </div>
<body>




</body>
</html>