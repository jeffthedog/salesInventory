<?php

// Start session
@session_start();

// Function to check if a user is logged in
function isUserLoggedIn() {
    return isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true;
}

// Function to redirect to login page if user is not logged in
function redirectToLogin() {
    if (!isUserLoggedIn()) {
        header("Location: loginform.php"); // Adjust the login page URL as needed
        exit;
    }
}

// Example: Function to check if the user has admin privileges
function isAdmin() {
    return isset($_SESSION['username']) && $_SESSION['username'] === 'admin';
}

// Example: Function to redirect to access denied page if user is not an admin
function redirectToAccessDenied() {
    if (!isAdmin()) {
        header("Location: wrongcredentialsadmin.php"); // Adjust the access denied page URL as needed
        exit;
    }
}

// Example: Function to log out the user
// Function to log out the user and regenerate the session ID
function logoutUser() {
    // Destroy the current session
    session_unset();
    session_destroy();
    
    // Regenerate session ID to prevent session fixation
    session_regenerate_id(true);
    
    // Start a new session
    session_start();
    
    // Redirect to the login page
    header("Location: login.php"); // Adjust the login page URL as needed
    exit;
}

?>


