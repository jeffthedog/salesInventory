<?php
include 'database.php';
// Create connection
$conn = new mysqli($db_hostname, $db_username, $db_password, $db_database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$selected_answer = '';
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['faq_id'])) {
    $faq_id = $_POST['faq_id'];
    $stmt = $conn->prepare("SELECT answer FROM faqs WHERE id = ?");
    $stmt->bind_param("i", $faq_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $selected_answer = $row['answer'];
}

// Fetch FAQs
$faq_result = $conn->query("SELECT id, question FROM faqs");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Help Chat</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
        }
        .sidebar {
            width: 240px;
            background-color: #333;
            color: #fff;
            height: 100vh;
            padding: 20px;
        }
        .sidebar h1 {
            color: #fff;
        }
        .content {
            flex-grow: 1;
            padding: 20px;
        }
        .faq-question {
            cursor: pointer;
            background-color: #f2f2f2;
            border: 1px solid #ddd;
            padding: 10px;
            margin-bottom: 5px;
            border-radius: 5px;
        }
        .faq-answer {
            background-color: #e9ffe9;
            border: 1px solid #d2f8d2;
            padding: 10px;
            margin-top: 20px;
            border-radius: 5px;
        }
    </style>
</head>
<body>

<div class="sidebar">
    <h1>Session 1</h1>
</div>

<div class="content">
    <h2>Help Topics</h2>
    <?php while($row = $faq_result->fetch_assoc()): ?>
        <div class="faq-question">
            <!-- Form now points to "help.php" -->
            <form action="help.php" method="post">
                <input type="hidden" name="faq_id" value="<?php echo $row['id']; ?>">
                <input type="submit" value="<?php echo htmlspecialchars($row['question']); ?>">
            </form>
        </div>
    <?php endwhile; ?>

    <?php if (!empty($selected_answer)): ?>
        <div class="faq-answer">
            <strong>Answer:</strong> <?php echo $selected_answer; ?>
        </div>
    <?php endif; ?>
</div>

</body>
</html>
<?php
$conn->close();
