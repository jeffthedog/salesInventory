<?php

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Session Expired</title>
    
to your CSS stylesheet -->
<style>
/* General Body Style */
body {
    font-family: 'Arial', sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}

/* Modal Styling */
#session-expired-modal {
    background: rgba(0, 0, 0, 0.7);
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
}

.modal-content {
    background-color: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
    text-align: center;
    width: 80%;
    max-width: 400px;
}

/* Heading Style */
h2 {
    color: #333;
    margin-bottom: 10px;
}

/* Paragraph Style */
p {
    color: #555;
    font-size: 1em;
}

/* Button Styling */
button {
    background-color: #007bff;
    color: #fff;
    border: none;
    padding: 10px 20px;
    border-radius: 5px;
    cursor: pointer;
    font-size: 1em;
    transition: background-color 0.3s ease;
}

button:hover {
    background-color: #0056b3;
}

/* Responsive Design */
@media (max-width: 600px) {
    .modal-content {
        width: 95%;
        padding: 15px;
    }
}

</style>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script> <!-- If you're using jQuery -->

</head>
<body>
    <div id="session-expired-modal">
        <div class="modal-content">
            <h2>Session Expired</h2>
            <p>Your session has expired. Please login again.</p>
            <button id="login">LOGIN</button>
        </div>
    </div>
<script>
    // Redirect to login page after 5 seconds or on button click
    setTimeout(function() {
        window.location.href = 'loginform.php';
    }, 5000);

    // If the user clicks the login button, redirect immediately
    document.getElementById('login').onclick = function() {
        window.location.href = 'loginform.php';
    };
</script>
</body>
</html>