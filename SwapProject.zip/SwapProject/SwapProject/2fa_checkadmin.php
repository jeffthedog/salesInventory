<?php
@session_start();
require_once 'GoogleAuthenticator-master/PHPGangsta/GoogleAuthenticator.php'; // Include the library

// Function to generate a random secret key (You can replace this with your own method)
function generateSecretKey() {
    $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'; // Base32 characters
    $secretKey = '';
    
    // Generate a random 20-character (160-bit) secret key
    for ($i = 0; $i < 20; $i++) {
        $secretKey .= $characters[random_int(0, strlen($characters) - 1)];
    }
    
    return $secretKey;
}

// Check if the user has enabled 2FA, and if not, generate a secret key for them
if (!isset($_SESSION['2fa_secret'])) {
    $secretKey = generateSecretKey();
    $_SESSION['2fa_secret'] = $secretKey;
    // Normally you would save this secret key in your database associated with the user's account.
}

$secretKey = $_SESSION['2fa_secret'];

// Create an instance of GoogleAuthenticator
$ga = new PHPGangsta_GoogleAuthenticator();

// Function to verify TOTP code
function verifyTOTPCode($secretKey, $code) {
    global $ga;
    $isCodeValid = $ga->verifyCode($secretKey, $code, 1); // 1 is the acceptable time drift (adjust as needed)
    return $isCodeValid;
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['2fa_code'])) {
        $code = $_POST['2fa_code']; // Make sure to validate and sanitize user input
        
        // Verify the TOTP code
        if (verifyTOTPCode($secretKey, $code)) {
            $_SESSION['loggedin'] = true;
            header("Location: admin_home.php");
            exit;
        } else {
            $error = "Invalid 2FA code. Please try again.";
        }
    }
}


$userDisplayName = 'User';


$displayName = "{$userDisplayName} "; // Create a display name that includes the user's name and issuer.

$encodedDisplayName = urlencode($displayName); // ensure it is correctly formatted for the QR code.

// Create URL for the code
$qrCodeUrl = $ga->getQRCodeGoogleUrl($encodedDisplayName, $secretKey, 'Mango Pomelo'); // Replace 'Mango Pomelo' with your app or company name.

?>

<!DOCTYPE html>
<html>
<head>
    <title>2FA Verification</title>
    <style>
        body {
            background-color: #333; /* Dark background for the page */
            font-family: Arial, sans-serif; /* Font style */
            color: white; /* White text */
        }

    form {
        background-color: #fff; /* White background for the form */
        border-radius: 5px; /* Rounded corners */
        padding: 20px; /* Spacing inside the form */
        width: 300px; /* Fixed width */
        margin: 100px auto; /* Center the form on the page */
        box-shadow: 0 0 10px rgba(0,0,0,0.5); /* Shadow for depth */
    }

    label {
        color: #333; /* Dark text for better readability on white background */
        display: block; /* Ensure label is on its own line */
        margin-bottom: 5px; /* Space between label and input */
    }

    input[type="text"],
    input[type="password"] {
        border: 1px solid #ddd; /* Light grey border */
        border-radius: 3px; /* Slightly rounded corners */
        padding: 10px; /* Space inside the inputs */
        width: 100%; /* Make inputs fill their container */
        box-sizing: border-box; /* Include padding in width calculation */
        margin-bottom: 20px; /* Space between each input */
    }

    input[type="submit"] {
        background-color: #4CAF50; /* Green background */
        color: white; /* White text */
        border: none; /* No border */
        padding: 15px 20px; /* Bigger padding for a larger button */
        text-transform: uppercase; /* Uppercase text */
        font-weight: bold; /* Bold font */
        cursor: pointer; /* Pointer cursor on hover */
        width: 100%; /* Full width */
        display: block; /* Block-level to fit width */
        border-radius: 5px; /* Rounded corners */
}


    input[type="submit"]:hover {
        background-color: #45a049; /* Slightly darker green on hover */
    }

    .error {
        color: #FF0000; /* Red color for error messages */
        margin-bottom: 20px; /* Space below the error message */
    }

    img {
        display: block; /* Display QR code as block */
        margin: 20px auto; /* Center QR code */
        max-width: 100%; /* Ensure it is not bigger than its container */
        height: auto; /* Maintain aspect ratio */
    }
</style>
</head>
<body>
    <?php if (isset($error)): ?>
    <p class="error"><?php echo $error; ?></p>
    <?php endif; ?>

<form action="2fa_checkadmin.php" method="post">
    <label for="2fa_code">Enter your 2FA code:</label>
    <input type="text" id="2fa_code" name="2fa_code" required>
    <input type="submit" value="Verify">
</form>

<!-- Display the QR code -->
<?php if (isset($qrCodeUrl)): ?>
<img src="<?php echo htmlspecialchars($qrCodeUrl); ?>" alt="2FA QR Code" />
<?php else: ?>
<p>QR code URL is missing or invalid.</p>
<?php endif; ?>
</body>
</html>