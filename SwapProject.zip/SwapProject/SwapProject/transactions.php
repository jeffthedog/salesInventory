<?php
@session_start();
include 'database.php';

require_once "auth.php";

// Check if the user is logged in
redirectToLogin();

// Check if the user has admin privileges
redirectToAccessDenied();



// Function to sanitize user input
function sanitizeInput($input, $minLength = 0) {
    // Remove HTML tags, trim leading/trailing whitespaces, and convert special characters
    $sanitizedInput = htmlspecialchars(strip_tags(trim($input)), ENT_QUOTES, 'UTF-8');
    
    // Ensure the input contains only alphanumeric characters
    $sanitizedInput = preg_replace("/[^a-zA-Z0-9]+/", "", $sanitizedInput);
    
    // Ensure the input meets the minimum length requirement
    if (strlen($sanitizedInput) < $minLength) {
        $sanitizedInput = ''; // Set to empty if below the minimum length
    }
    
    return $sanitizedInput;
}

// Process the search for transactions by user
if (isset($_GET['searchUser'])) {
    $searchUser = sanitizeInput($_GET['searchUser']);
    $searchTransactionId = isset($_GET['searchTransactionId']) ? sanitizeInput($_GET['searchTransactionId']) : '';
    
    // Prepared SQL statement
    $selectTransactionsQuery = "SELECT transaction.*, user.USERNAME
    FROM transaction
    JOIN user ON transaction.user = user.id
    WHERE user.USERNAME LIKE CONCAT('%', ?, '%') AND transaction.id LIKE CONCAT('%', ?, '%')
    ORDER BY transaction.date DESC;";
    
    $stmt = $con->prepare($selectTransactionsQuery);
    $searchUser = "%$searchUser%"; // Adding wildcards for partial matching
    $searchTransactionId = "%$searchTransactionId%";
    $stmt->bind_param('ss', $searchUser, $searchTransactionId);
    $stmt->execute();
    $resultTransactions = $stmt->get_result();
    $stmt->close();
}else {
    // Default query 
    $selectTransactionsQuery = 'SELECT transaction.*, user.USERNAME
    FROM transaction
    JOIN user ON transaction.user = user.id
    ORDER BY transaction.date DESC;';
    
    
    $resultTransactions = $con->query($selectTransactionsQuery);
}


?>

<style>
    table {
        border-collapse: collapse;
        width: 100%;
    }

    th, td {
        border: 1px solid #ddd;
        padding: 8px;
        text-align: left;
    }

    th {
        background-color: #f2f2f2;
    }

    tr:hover {
        background-color: #f5f5f5;
    }

    /* Add your own styling for the dropdown button if needed */
    .dropdown-btn {
        padding: 5px 10px;
        background-color: #4CAF50;
        color: white;
        border: none;
        border-radius: 3px;
        cursor: pointer;
    }

    /* Hide the details row initially */
    .details-row {
        display: none;
    }
    
    .body {
        font-family: Arial, sans-serif;
    }
    .header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 20px;
    }
    .nav {
        list-style-type: none;
        display: flex;
        gap: 20px;
    }
    .nav li {
        display: inline;
    }
    .search-bar {
        display: flex;
        gap: 10px;
    }
    .search-bar input {
        padding: 5px;
    }
    .sidebar {
        float: left;
        width: 20%;
        height: 100vh;
        background-color: #f0f0f0;
        padding: 20px;
    }
    .content {
        float: right;
        width: 80%;
        height: 100vh;
        background-color: #fff;
        padding: 20px;
    }
    .sidebar ul {
        list-style-type: none;
        padding: 0;
    }
    .sidebar li {
        margin-bottom: 10px;
        cursor: pointer; /* Add this line to make the items clickable */
    }
    /* Clear floats after the columns */
    .row:after {
        content: "";
        display: table;
        clear: both;
    }
</style>
<?=admin_header('Admin_Home')?>
<body>
    <div class="row">
        <div class="sidebar">
            <ul>
                <li><a href="sales_chart.php">Sales</a></li>
            	<li><a href="transactions.php">Transactions</a></li>
                <li><a href="usermanagement.php">Users</a></li>
                <li><a href="admin_home.php">Products</a></li>
            </ul>
        </div>
        <div class="content">
			<h1>Transactions</h1>
            <!-- search form -->
            <form method="GET" action="transactions.php">
                <label for="searchUser">Username:</label>
                <input type="text" id="searchUser" name="searchUser">
                
                <label for="searchTransactionId">Transaction ID:</label>
                <input type="text" id="searchTransactionId" name="searchTransactionId">
                
                <input type="submit" name="search" value="Search">
            </form>
            
            <table>
                <thead>
                    <tr>
                        <th><input type="checkbox" id="select-all">Select All</th>
                        <th>ID</th>
                        <th>Date</th>
                        <th>Description</th>
                        <th>Account</th>
                        <th>Amount</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $previousTransactionId = null; // Variable to track the previous TRANSACTION_ID
                    while ($row = $resultTransactions->fetch_assoc()):
                        ?>
                        <tr>
                            <td><input type="checkbox" name="transaction_ids[]" value="<?= $row['ID'] ?>"></td>
                            <td><?= $row['ID'] ?></td>
                            <td><?= $row['DATE'] ?></td>
                            <td><?= $row['DESCRIPTION'] ?></td>
                            <td><?= $row['USERNAME'] ?></td>
                            <td>$<?= $row['TRANSACTION_TOTAL'] ?></td>
                            <td>
                            	<button class="dropdown-btn options-btn" onclick="toggleDetails('details-row-<?= $row['ID'] ?>', '<?= $row['ID'] ?>')">More</button>
                    		</td>
                		</tr>
                        <tr class="details-row" id="details-row-<?= $row['ID'] ?>">
                            <td colspan="6">
                                <strong>Transaction Items:</strong><br>
                                <!-- code to fetch and display transaction items -->
                                <?php
                                // Fetch and display transaction items for the current transaction ID
                                $transactionId = $row['ID'];
                                $selectTransactionItemsQuery = "SELECT transaction_items.*, item.ITEM_NAME, item.ITEM_PRICE, user.USERNAME
                                FROM transaction_items
                                JOIN item ON transaction_items.item_selected = item.id
                                JOIN transaction ON transaction_items.transaction_id = transaction.id
                                JOIN user ON transaction.user = user.id
                                WHERE transaction_items.transaction_id = $transactionId";
                                
                                $resultTransactionItems = $con->query($selectTransactionItemsQuery);
            
                                while ($transactionItem = $resultTransactionItems->fetch_assoc()) {
                                    echo '- Product ID: ' . $transactionItem['ITEM_SELECTED'] . '<br>';
                                    echo '- Product Name: ' . $transactionItem['ITEM_NAME'] . '<br>';
                                    echo '- Quantity: ' . $transactionItem['QUANTITY'] . '<br>';
                                    echo '- Item Price: $' . $transactionItem['ITEM_PRICE'] . '<br>';
                                    
                                    // Calculate and display the total cost for the current item
                                    $totalCost = (float)$transactionItem['ITEM_PRICE'] * (int)$transactionItem['QUANTITY'];
                                    echo '- Total Cost: $' . number_format($totalCost, 2) . '<br>';
                                    
                                    echo '<br>';
                                }
                                ?>
                            </td>
                        </tr>
                        <?php
                        $previousTransactionId = $row['ID'];
                    endwhile;
                    ?>
                </tbody>
            </table>
                    </div>
                </div>

</body>



<script>
    document.getElementById('select-all').addEventListener('change', function () {
        var checkboxes = document.querySelectorAll('input[name="transaction_ids[]"]');
        checkboxes.forEach(function (checkbox) {
            checkbox.checked = event.target.checked;
        });
    });

    function toggleDetails(detailsRowId, transactionId) {
        var detailsRow = document.getElementById(detailsRowId);
        if (detailsRow.style.display === 'table-row') {
            detailsRow.style.display = 'none';
        } else {
            detailsRow.style.display = 'table-row';
            createOptions(transactionId);
        }
    }


// Close the dropdown if the user clicks outside of it
window.onclick = function (event) {
    if (!event.target.matches('.options-btn')) {
        var dropdowns = document.querySelectorAll('.options-container');
        dropdowns.forEach(function (dropdown) {
            // Hide all edit forms
            var editForms = dropdown.querySelectorAll('.edit-form');
            editForms.forEach(function (editForm) {
                editForm.style.display = 'none';
            });

            dropdown.style.display = 'none';
        });
    }
}
</script>
