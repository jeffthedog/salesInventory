<?php
include 'database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve and sanitize form data
    $editQuantity = sanitizeInput($_POST['quantity']);
    $editTransactionId = sanitizeInput($_POST['transaction_id']);
    $editItemSelected = sanitizeInput($_POST['item_selected']);
    
    // Validate the data (add your validation logic here)
    
    // Update the transaction items in the database
    $updateTransactionItemsQuery = "UPDATE transaction_items
        SET QUANTITY = ?, ITEM_SELECTED = ?
        WHERE transaction_id = ?";
    
    $stmtUpdate = $con->prepare($updateTransactionItemsQuery);
    $stmtUpdate->bind_param('ssi', $editQuantity, $editItemSelected, $editTransactionId);
    
    if ($stmtUpdate->execute()) {
        // Update successful
        $response = ['success' => true, 'message' => 'Update successful'];
    } else {
        // Update failed
        $response = ['success' => false, 'message' => 'Error updating transaction items: ' . $stmtUpdate->error];
    }
    
    // Send JSON response
    header('Content-Type: application/json');
    echo json_encode($response);
    
    $stmtUpdate->close();
} else {
    // Invalid request method
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}
?>
