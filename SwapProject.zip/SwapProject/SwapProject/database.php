<?php	

require_once "config.php";

function printerror($message, $con) {
    echo "<pre>";
    echo "$message<br>";
    if ($con) echo "FAILED: ".mysqli_error($con)."<br>";
    echo "</pre>";
}


try {
    $con=mysqli_connect($db_hostname,$db_username,$db_password, $db_database);
}
catch (Exception $e) {
    printerror($e->getMessage(),$con);
}
if (!$con) {
    printerror("Connecting to $db_hostname", $con);
    die();
}

$query="SHOW TABLES";
$result=mysqli_query($con,$query);
if (!$result) {
    printerror($query,$con);
    die();
}
else;


$result=mysqli_query($con,$query);
if (!$result) {
    printerror("Selecting $db_database",$con);
    die();
}
else;


function website_header($title) {
    // Get the number of items in the shopping cart, which will be displayed in the header.
    $num_items_in_cart = isset($_SESSION['cart']) ? count($_SESSION['cart']) : 0;
    
    echo <<<EOT
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>$title</title>
        <link href="style.css" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
    </head>
    <body>
        <header>
            <div class="content-wrapper">
                <h1>Mango Pomelo</h1>
                <nav>
                    <a href="index.php">Home</a>
                    <a href="index.php?page=products">Products</a>
                </nav>
                <div class="link-icons">
EOT;
    
    // Check if the 'username' session variable is set
    if (isset($_SESSION['username'])) {
        echo '<h3>Welcome, ' . $_SESSION['username'] . '</h3>';
        
        // Check if the 'id' session variable is not set and set it
        if (!isset($_SESSION['id'])) {
            // Assuming your id is stored in the session during login
            // Adjust this based on how your user data is stored in the session
            $_SESSION['id'] = get_user_id_by_username($_SESSION['username']);
        }
    } else {
        echo '<a href="loginform.php" class="login-button">Login</a>';
    }
    
    echo <<<EOT
                    <a href="index.php?page=cart">
                        <i class="fas fa-shopping-cart"></i>
                        <span>$num_items_in_cart</span>
                    </a>
                </div>
            </div>
        </header>
        <main>
EOT;
}


// Template footer
function website_footer() {
    $year = date('Y');
    echo <<<EOT
        </main>
        <footer>
            <div class="content-wrapper">
                <p>&copy; $year, Advanced Manufacturing Centre @ Temasek Polytechnic </p>
            </div>
        </footer>
    </body>
</html>
EOT;
}


function admin_header($admin) {
    echo <<<EOT
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="utf-8">
            <title>$admin</title>
            <link href="style.css" rel="stylesheet" type="text/css">
            <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
        </head>
        <body>
            <header>
                <div class="content-wrapper">
                    <h1>Mango Pomelo Admin Page</h1>
                    <nav>
                        <a href="index.php?page=Admin_Home">Home</a>
                        <a href="index.php?page=dashboard">Dashboard</a>
                    </nav>
                    <div class="link-icons">
EOT;
    
    // Check if the 'username' session variable is set
    if (isset($_SESSION['username'])) {
        echo '<h3>Welcome, ' . $_SESSION['username'] . '</h3>';
        
        // Check if the 'id' session variable is not set and set it
        if (!isset($_SESSION['id'])) {
            // Assuming your id is stored in the session during login
            // Adjust this based on how your user data is stored in the session
            $_SESSION['id'] = get_user_id_by_username($_SESSION['username']);
        }
    } else {
        echo '<a href="admin_loginform.php" class="login-button">Login</a>';
    }
    
    echo <<<EOT
                    </div>
                </div>
            </header>
            <main>
    EOT;
}



?>