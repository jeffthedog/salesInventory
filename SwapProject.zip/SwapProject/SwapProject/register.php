<?php
@session_start();
require_once "database.php"; 

function sanitizeData($data) { // Function to sanitize user input 
    return htmlspecialchars(stripslashes(trim($data)));
}

function generateSecretKey($length = 16) { // generates a random secret key for two-factor authentication
    $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'; 
    $secret = '';
    for ($i = 0; $i < $length; $i++) {
        $secret .= $characters[rand(0, strlen($characters) - 1)]; // Randomly select a character and append to the secret
    }
    return $secret;
}

function getQRCodeGoogleUrl($username, $secretKey, $issuer = null) { // Function to generate a Google QR code URL for two-factor authentication setup
    $url = 'otpauth://totp/';
    $url .= urlencode($issuer ? "{$issuer}:{$username}" : $username);
    $url .= "?secret={$secretKey}";
    if ($issuer) {
        $url .= "&issuer=".urlencode($issuer);
    }
    return $url;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") { // Sanitize all the form input data
    $name = sanitizeData($_POST['name']);
    $username = sanitizeData($_POST['username']);
    $email = sanitizeData($_POST['email']);
    $contact = sanitizeData($_POST['contact']);
    $address = sanitizeData($_POST['address']);
    $password = sanitizeData($_POST['password']);
    $confirm_password = sanitizeData($_POST['confirm_password']);
    $role = 'user'; // Sets the default user to 'user'
    
    if ($password !== $confirm_password) { // Check if the password and confirm password match
        die('Passwords do not match.');
    }
    
    $hashed_password = password_hash($password, PASSWORD_DEFAULT); // Hash the password before storing it
    $secretKey = generateSecretKey();
    
    // Add new user to the database
    $stmt = $con->prepare("INSERT INTO user (NAME, USERNAME, PASSWORD, ADDRESS, EMAIL, CONTACT, ROLE, SECRET) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssssss", $param_name, $param_username, $param_password, $param_address, $param_email, $param_contact, $param_role, $secretKey);
    
    $param_name = $name;
    $param_username = $username;
    $param_password = $hashed_password;
    $param_address = $address;
    $param_email = $email;
    $param_contact = $contact;
    $param_role = $role;
    
    if ($stmt->execute()) {
        $qrCodeUrl = getQRCodeGoogleUrl($username, $secretKey, 'YourIssuerName');
        echo "QR Code URL: " . $qrCodeUrl; // Display URL code
    } else {
        echo "Something went wrong. Please try again later.";
    }
    
    header("Location: loginform.php");
    
    $stmt->close();
    $con->close();
}
?>
