<?php
@session_start();

// Check for errors
if (isset($_GET['error'])) {
    $error = $_GET['error'];
    switch ($error) {
        case 'search_term_too_long':
            $errorMessage = "Search term is too long.";
            break;
        case 'invalid_search_pattern':
            $errorMessage = "Invalid search term pattern.";
            break;
            // Add more cases for other error codes if needed
        default:
            $errorMessage = "An error occurred.";
    }
    
    // Display the error message to the user
    echo '<p style="color: red;">' . $errorMessage . '</p>';
}
// Function to get products based on the specified filter and search query
function getProducts($con, $filter, $search) {
    $baseQuery = 'SELECT * FROM `filter`
                  JOIN `item` ON `filter`.`ITEM_ID` = `item`.`ID`';
    
    // search query
    if (!empty($search)) {
        // Validate input length
        if (strlen($search) > 50) {
            // Redirect with an error message
            header("Location: products.php?error=search_term_too_long");
            exit;
        }
        
        // Validate input pattern using regular expression
        if (!preg_match('/^[a-zA-Z0-9\s*]+$/', $search)) {
            // Redirect with an error message
            header("Location: products.php?error=invalid_search_pattern");
            exit;
        }
        
        // Use prepared statement with LIKE
        $searchQuery = " WHERE `item`.`ITEM_NAME` LIKE ?";
        $searchParam = str_replace('*', '%', $search) . "%";
    } else {
        $searchQuery = '';
        $searchParam = null;
    }
    
    
    
    switch ($filter) {
        case 'recent':
            $query = $baseQuery . $searchQuery . ' ORDER BY `item`.`ID` ASC';
            break;
        case 'price':
            $query = $baseQuery . $searchQuery . ' ORDER BY `filter`.`PRICE` ASC';
            break;
        case 'popularity':
            $query = $baseQuery . $searchQuery . ' ORDER BY `filter`.`POPULARITY` ASC';
            break;
        default:
            $query = $baseQuery . $searchQuery;
    }
    
    $stmt = $con->prepare($query);
    
    // Bind the parameter for the search query
    if ($searchParam !== null) {
        $stmt->bind_param('s', $searchParam);
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}

// Check if a filter and search query are specified in the URL
$filter = isset($_GET['filter']) ? $_GET['filter'] : '';
$search = isset($_GET['search']) ? $_GET['search'] : '';

// Get products based on the specified filter and search query
$products = getProducts($con, $filter, $search);

// Get the number of rows
$total_products = count($products);
?>

<style>
    .dropdown {
        display: inline-block;
    }

    .dropbtn {
        background-color: #3498db;
        color: white;
        padding: 8px;
        font-size: 16px;
        border: none;
        cursor: pointer;
    }

    .dropdown-content {
        display: none;
        position: absolute;
        background-color: #f9f9f9;
        min-width: 160px;
        box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
        z-index: 1;
    }

    .dropdown-content a {
        color: black;
        padding: 12px 16px;
        text-decoration: none;
        display: block;
    }

    .dropdown-content a:hover {
        background-color: #f1f1f1;
    }

    .dropdown:hover .dropdown-content {
        display: block;
    }

    .dropdown:hover .dropbtn {
        background-color: #2980B9;
    }
</style>

<?=website_header('Products')?>

<div class="products content-wrapper">
    <h1>Products</h1>
    <p><?=$total_products?> Products</p>
    
    <div class="search-bar">
    <form action="index.php" method="GET">
        <input type="hidden" name="page" value="products">
        <input type="text" name="search" placeholder="Search for products">
        <button type="submit">Search</button>
    </form>
	</div>
   
    <div class="filter-options">
        <div class="dropdown">
            <button class="dropbtn">Filter</button>
            <div class="dropdown-content">
                <a href="index.php?page=products&filter=recent">Recent</a>
                <a href="index.php?page=products&filter=price">Price</a>
                <a href="index.php?page=products&filter=popularity">Popularity</a>
            </div>
        </div>
    </div>

    <div class="products-wrapper">
        <?php foreach ($products as $product): ?>
        <a href="index.php?page=product&id=<?=$product['ID']?>" class="product">
            <img src="<?=$product['IMAGE']?>" width="200" height="200" alt="<?=$product['ITEM_NAME']?>">
            <span class="name"><?=$product['ITEM_NAME']?></span>
            <span class="price">
                &dollar;<?=$product['ITEM_PRICE']?>
            </span>
        </a>
        <?php endforeach; ?>
    </div>
</div>


<?=website_footer()?>
