<?php
@session_start();
// If the user clicked the add to cart button on the product page we can check for the form data
if (isset($_POST['product_id'], $_POST['quantity']) && is_numeric($_POST['product_id']) && is_numeric($_POST['quantity'])) {
    // Set the post variables so we easily identify them, also make sure they are integer
    $product_id = (int)$_POST['product_id'];
    $quantity = (int)$_POST['quantity'];
    
    // Prepare the SQL statement, we basically are checking if the product exists in our database
    $stmt = $con->prepare('SELECT * FROM item WHERE id = ?');
    $stmt->bind_param('i', $product_id);
    $stmt->execute();
    
    // Get the result set from the query
    $result = $stmt->get_result();
    
    // Fetch the product from the result set and return the result as an array
    $product = $result->fetch_assoc();
    
    // Check if the product exists (array is not empty)
    if ($product && $quantity > 0) {
        // Product exists in the database, now we can create/update the session variable for the cart
        if (isset($_SESSION['cart']) && is_array($_SESSION['cart'])) {
            if (array_key_exists($product_id, $_SESSION['cart'])) {
                // Product exists in the cart so just update the quantity
                $_SESSION['cart'][$product_id] += $quantity;
            } else {
                // Product is not in the cart, so add it
                $_SESSION['cart'][$product_id] = $quantity;
            }
        } else {
            // There are no products in the cart, this will add the first product to the cart
            $_SESSION['cart'] = array($product_id => $quantity);
        }
    }
    
    // Prevent form resubmission...
    header('location: index.php?page=cart');
    exit;
}

// Remove product from cart, check for the URL param "remove", this is the product id, make sure it's a number and check if it's in the cart
if (isset($_GET['remove']) && is_numeric($_GET['remove']) && isset($_SESSION['cart']) && isset($_SESSION['cart'][$_GET['remove']])) {
    // Assuming $con is a valid MySQLi connection
    // Prepare the SQL statement, we basically are checking if the product exists in our database
    $stmt = $con->prepare('SELECT * FROM item WHERE id = ?');
    $stmt->bind_param('i', $_GET['remove']);
    $stmt->execute();
    
    // Get the result set from the query
    $result = $stmt->get_result();
    
    // Fetch the product from the result set and return the result as an array
    $product = $result->fetch_assoc();
    
    // Check if the product exists (array is not empty)
    if ($product) {
        // Remove the product from the shopping cart
        unset($_SESSION['cart'][$_GET['remove']]);
    }
    
    // Close the statement
    $stmt->close();
}

// Update product quantities in cart if the user clicks the "Update" button on the shopping cart page
if (isset($_POST['update']) && isset($_SESSION['cart'])) {
    // Assuming $con is a valid MySQLi connection
    foreach ($_POST as $k => $v) {
        if (strpos($k, 'quantity') !== false && is_numeric($v)) {
            $id = str_replace('quantity-', '', $k);
            $quantity = (int)$v;
            // Always do checks and validation
            if (is_numeric($id) && isset($_SESSION['cart'][$id]) && $quantity > 0) {
                // Assuming $con is a valid MySQLi connection
                // Prepare the SQL statement, we basically are checking if the product exists in our database
                $stmt = $con->prepare('SELECT * FROM item WHERE id = ?');
                $stmt->bind_param('i', $id);
                $stmt->execute();
                
                // Get the result set from the query
                $result = $stmt->get_result();
                
                // Fetch the product from the result set and return the result as an array
                $product = $result->fetch_assoc();
                
                // Check if the product exists (array is not empty)
                if ($product) {
                    // Update new quantity
                    $_SESSION['cart'][$id] = $quantity;
                }
                
                // Close the statement
                $stmt->close();
            }
        }
    }
    // Prevent form resubmission...
    header('location: index.php?page=cart');
    exit;
}

// Send the user to the place order page if they click the Place Order button, also the cart should not be empty
if (isset($_POST['placeorder']) && isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
    // Check if the user is logged in
    if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
        // Display an alert and redirect to the loginform.php
        echo <<<EOT
        <script>
            alert("You must log in first to checkout.");
            window.location.href = "loginform.php";
        </script>
EOT;
        exit;
    } else {
        // Proceed with the confirmation popup
        echo <<<EOT
        <script>
            var confirmationMessage = "Do you want to place the order?"; // Customize this message if needed
            var confirmation = confirm(confirmationMessage);
            
            if (!confirmation) {
                // User clicked "Cancel", prevent the form submission
                event.preventDefault();
            }
        </script>
EOT;
        
        $con->autocommit(true);
    }

    
    try {
        // Get id from the session
        $user_id = isset($_SESSION['id']) ? $_SESSION['id'] : null;
        
        // Check if user_id is available in the session
        if ($user_id === null) {
            throw new Exception('User ID not found in session.');
        }
        
        $description = "Invoice payment";
        $date = date("Y-m-d H:i:s");
        
        // Accumulate subtotal for all products
        $total_subtotal = 0.00;
        
        foreach ($_SESSION['cart'] as $product_id => $quantity) {
            $selectProductQuery = 'SELECT ITEM_PRICE FROM item WHERE ID = ?';
            $stmtProduct = $con->prepare($selectProductQuery);
            $stmtProduct->bind_param('i', $product_id);
            $stmtProduct->execute();
            $result = $stmtProduct->get_result();
            $product = $result->fetch_assoc();
            
            // Calculate subtotal for each item
            $subtotal = (float)$product['ITEM_PRICE'] * $quantity;
            $total_subtotal += $subtotal;
        }
        
        // Insert a single row into the transaction table with the total subtotal
        $insertTransactionQuery = 'INSERT INTO transaction (TRANSACTION_TOTAL, DATE, DESCRIPTION, USER) VALUES (?, ?, ?, ?);';
        $stmtTransaction = $con->prepare($insertTransactionQuery);
        $stmtTransaction->bind_param('dssi', $total_subtotal, $date, $description, $user_id);
        $stmtTransaction->execute();
        
        if (!$stmtTransaction->affected_rows) {
            // If the affected_rows is 0, the insert didn't happen. Handle this case accordingly.
            throw new Exception('Failed to insert transaction.');
        }
        
        // Get the transaction ID
        $transactionID = $stmtTransaction->insert_id;
        
        // Insert transaction items into the transaction_items table
        foreach ($_SESSION['cart'] as $product_id => $quantity) {
            $selectProductQuery = 'SELECT ITEM_PRICE FROM item WHERE ID = ?';
            $stmtProduct = $con->prepare($selectProductQuery);
            $stmtProduct->bind_param('i', $product_id);
            $stmtProduct->execute();
            $result = $stmtProduct->get_result();
            $product = $result->fetch_assoc();
            
            // Calculate subtotal for each item
            $subtotal = (float)$product['ITEM_PRICE'] * $quantity;
            
            // Insert into transaction_items table
            $insertTransactionItemQuery = 'INSERT INTO transaction_items (QUANTITY, TRANSACTION_ID, ITEM_SELECTED) VALUES (?, ?, ?)';
            $stmtTransactionItem = $con->prepare($insertTransactionItemQuery);
            $stmtTransactionItem->bind_param('iis', $quantity, $transactionID, $product_id);
            $stmtTransactionItem->execute();
            
            if (!$stmtTransactionItem->affected_rows) {
                // If the affected_rows is 0, the insert didn't happen. Handle this case accordingly.
                throw new Exception('Failed to insert transaction item.');
            }
        }
        
        foreach ($_SESSION['cart'] as $product_id => $quantity) {
            $updateStockQuery = 'UPDATE item SET STOCK = STOCK - ? WHERE id = ?';
            $stmt = $con->prepare($updateStockQuery);
            $stmt->bind_param('ii', $quantity, $product_id);
            $stmt->execute();
            
            if (!$stmt->affected_rows) {
                // If the affected_rows is 0, the update didn't happen. Handle this case accordingly.
                throw new Exception('Failed to update stock.');
            }
        }
        
        // Clear the cart after successful order placement
        $_SESSION['cart'] = array();
        
        // Redirect to a confirmation page or any other page as needed
        header('Location: index.php?page=placeorder');
        
        // Commit the transaction
        $con->commit();
        
        exit;
        
    } catch (Exception $e) {
        // An error occurred, rollback the transaction
        $con->rollback();
        
        // Handle the error, you can redirect to an error page or show a message
        echo 'Error: ' . $e->getMessage();
    }
}

// Check the session variable for products in cart
$products_in_cart = isset($_SESSION['cart']) ? $_SESSION['cart'] : array();
$products = array();
$subtotal = 0.00;

// If there are products in cart
if ($products_in_cart) {
    // There are products in the cart so we need to select those products from the database
    // Products in cart array to question mark string array, we need the SQL statement to include IN (?,?,?,...etc)
    $array_to_question_marks = implode(',', array_fill(0, count($products_in_cart), '?'));
    $sql = 'SELECT * FROM item WHERE id IN (' . $array_to_question_marks . ')';
    
    // Prepare the SQL statement
    $stmt = $con->prepare($sql);
    
    // Bind parameters for the IN clause
    $stmt->bind_param(str_repeat('i', count($products_in_cart)), ...array_keys($products_in_cart));
    
    // Execute the statement
    $stmt->execute();
    
    // Get the result set from the query
    $result = $stmt->get_result();
    
    // Fetch the products from the result set and return the result as an array
    $products = $result->fetch_all(MYSQLI_ASSOC);
    
    // Calculate the subtotal
    foreach ($products as $product) {
        $subtotal += (float)$product['ITEM_PRICE'] * (int)$products_in_cart[$product['ID']];
    }
    
    // Close the statement
    $stmt->close();
}

?>

<?=website_header('Cart')?>

<div class="cart content-wrapper">
    <h1>Shopping Cart</h1>
    <form action="index.php?page=cart" method="post" id="cartForm">
        <table>
            <thead>
                <tr>
                    <td colspan="2">Product</td>
                    <td>Price</td>
                    <td>Quantity</td>
                    <td>Total</td>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($products)): ?>
                    <tr>
                        <td colspan="5" style="text-align:center;">You have no products added in your Shopping Cart</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($products as $product): ?>
                        <tr>
                            <td class="img">
                                <a href="index.php?page=product&id=<?=$product['ID']?>">
                                    <img src="<?=$product['IMAGE']?>" width="50" height="50" alt="<?=$product['ITEM_NAME']?>">
                                </a>
                            </td>
                            <td>
                                <a href="index.php?page=product&id=<?=$product['ID']?>"><?=$product['ITEM_NAME']?></a>
                                <br>
                                <a href="index.php?page=cart&remove=<?=$product['ID']?>" class="remove">Remove</a>
                            </td>
                            <td class="price">&dollar;<?=$product['ITEM_PRICE']?></td>
                            <td class="quantity">
                                <input type="number" name="quantity-<?=$product['ID']?>" value="<?=$products_in_cart[$product['ID']]?>" min="1" max="<?=$product['STOCK']?>" placeholder="Quantity" required>
                            </td>
                            <td class="price">&dollar;<?=$product['ITEM_PRICE'] * $products_in_cart[$product['ID']]?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
        <div class="subtotal">
            <span class="text">Subtotal</span>
            <span class="price">&dollar;<?=$subtotal?></span>
        </div>
        <div class="buttons">
            <input type="submit" value="Update" name="update">
            <input type="submit" value="Confirm Order" name="placeorder">
        </div>
    </form>
</div>

<script>
    function showLoginAlert() {
        alert("You must log in first to checkout.");
        window.location.href = "loginform.php";
    }

    document.addEventListener('DOMContentLoaded', function() {
        var confirmOrderButton = document.querySelector('input[name="placeorder"]');
        var updateButton = document.querySelector('input[name="update"]');
        var form = document.getElementById('cartForm');

        // Set the cart subtotal using a JavaScript variable
        var subtotal = <?= $subtotal ?>;

    // Add a click event listener to the form
    form.addEventListener('submit', function (event) {
        // Check if the "Confirm Order" button is clicked
        if (confirmOrderButton && confirmOrderButton.clicked) {
            // Check if the cart is empty
            if (subtotal === 0) {
                alert('Your cart is empty. Add items to your cart before confirming the order.');
                event.preventDefault();
            } else {
                <?php if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true): ?>
                    // User is not logged in, show login alert
                    showLoginAlert();
                    event.preventDefault();
                <?php else: ?>
                    // Cart is not empty, proceed with the confirmation message
                    var quantities = [];
                    var productNames = [];
                    <?php foreach ($products as $product): ?>
                        quantities.push(<?=(int)$products_in_cart[$product['ID']]?>);
                        productNames.push('<?=$product['ITEM_NAME']?>');
                    <?php endforeach; ?>
    
                    var confirmationMessage = "Do you want to place the order?\n";
                    for (var i = 0; i < quantities.length; i++) {
                        confirmationMessage += " - " + productNames[i] + ": " + quantities[i] + " item(s)\n";
                    }
                    confirmationMessage += "\nTotal Amount: $" + subtotal;
    
                    var confirmation = confirm(confirmationMessage);
    
                    if (!confirmation) {
                        // User clicked "Cancel", prevent the form submission
                        event.preventDefault();
                    }
                <?php endif; ?>
            }
        } else {
            // "Update" button is clicked
        }
    });


        // Add click event listeners to both buttons to track which one is clicked
        confirmOrderButton.addEventListener('click', function() {
            this.clicked = true;
        });

        updateButton.addEventListener('click', function() {
            confirmOrderButton.clicked = false;
        });
    });
</script>



<?=website_footer()?>

