<?php
@session_start();

require_once 'database.php';

require_once "auth.php";

// Check if the user is logged in
redirectToLogin();

// Check if the user has admin privileges
redirectToAccessDenied();


// Create
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action'])) {
    if ($_POST['action'] == 'create') {
        $name = $_POST['name'];
        $price = $_POST['price'];
        $stock = $_POST['stock'];
        $description = $_POST['description'];
        $specification = $_POST['specification'];
        $image = $_POST['image'];
        
        $stmt = $con->prepare("INSERT INTO item (ITEM_NAME, ITEM_PRICE, STOCK, DESCRIPTION, SPECIFICATION, IMAGE) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("siisss", $name, $price, $stock, $description, $specification, $image);
        $stmt->execute();
        
        if ($con->query($sql) === TRUE) {
            header("Location: product-management.php");
        } else {
            echo "Error: " . $sql . "<br>" . $con->error;
        }
    }
}

// Read
$sql = "SELECT * FROM item";
$result = $con->query($sql);

// Update
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action'])) {
    if ($_POST['action'] == 'update') {
        $id = $_POST['id'];
        $name = $_POST['name'];
        $price = $_POST['price'];
        $stock = $_POST['stock'];
        $description = $_POST['description'];
        $specification = $_POST['specification'];
        $image = $_POST['image'];
        
        $sql = "UPDATE item SET ITEM_NAME=?, ITEM_PRICE=?, STOCK=?, DESCRIPTION=?, SPECIFICATION=?, IMAGE=? WHERE ID=?";
        
        if ($con->query($sql) === TRUE) {
            header("Location: admin_home.php");
        } else {
            echo "Error updating record: " . $con->error;
        }
    }
}

// Delete
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    $id = $_GET['id'];
    
    $sql = "DELETE FROM item WHERE ID=$id";
    
    if ($con->query($sql) === TRUE) {
        header("Location: admin_home.php");
    } else {
        echo "Error deleting record: " . $con->error;
    }
}
?>

<?=admin_header('Admin_Home')?>

<style>

        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }


        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }


        td img {
            max-width: 50px;
            max-height: 50px;
        }

        .form-container {
            max-width: 600px;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .form-group {
            margin-bottom: 15px;
        }

        label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }

        input, textarea {
            width: 100%;
            padding: 8px;
            box-sizing: border-box;
            margin-bottom: 10px;
        }

        input[type="submit"] {
            background-color: #333;
            color: #fff;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            border-radius: 4px;
        }

        a {
            text-decoration: none;
            color: #333;
            margin-right: 10px;
        }

    .header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 20px;
    }
    .nav {
        list-style-type: none;
        display: flex;
        gap: 20px;
    }
    .nav li {
        display: inline;
    }
    .search-bar {
        display: flex;
        gap: 10px;
    }
    .search-bar input {
        padding: 5px;
    }
    .sidebar {
        float: left;
        width: 20%;
        height: 100vh;
        background-color: #f0f0f0;
        padding: 20px;
    }
    .content {
        float: right;
        width: 80%;
        height: 100vh;
        background-color: #fff;
        padding: 20px;
    }
    .sidebar ul {
        list-style-type: none;
        padding: 0;
    }
    .sidebar li {
        margin-bottom: 10px;
        cursor: pointer; /* Add this line to make the items clickable */
    }
    /* Clear floats after the columns */
    .row:after {
        content: "";
        display: table;
        clear: both;
    }
</style>
<body>
    <div class="row">
        <div class="sidebar">
            <ul>
                <li><a href="sales_chart.php">Sales</a></li>
            	<li><a href="transactions.php">Transactions</a></li>
                <li><a href="usermanagement.php">Users</a></li>
                <li><a href="admin_home.php">Products</a></li>
            </ul>
        </div>
        <div class="content">
        <table>
            <tr>
                <th>Item Name</th>
                <th>Price</th>
                <th>Stock</th>
                <th>Description</th>
                <th>Specification</th>
                <th>Image</th>
                <th>Action</th>
            </tr>
        
            <?php while($row = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo $row['ITEM_NAME']; ?></td>
                    <td><?php echo $row['ITEM_PRICE']; ?></td>
                    <td><?php echo $row['STOCK']; ?></td>
                    <td><?php echo $row['DESCRIPTION']; ?></td>
                    <td><?php echo $row['SPECIFICATION']; ?></td>
                    <td><img src="<?php echo $row['IMAGE']; ?>" alt="Product Image"></td>
                    <td>
                        <a href="admin_home.php?action=update&id=<?php echo $row['ID']; ?>">Edit</a>
                        <a href="admin_home.php?action=delete&id=<?php echo $row['ID']; ?>" onclick="return confirm('Are you sure?')">Delete</a>
                    </td>
                </tr>
            <?php } ?>
        
        </table>
        
        <?php
        if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['action']) && $_GET['action'] == 'update' && isset($_GET['id'])) {
            $id = $_GET['id'];
            $sql = "SELECT * FROM item WHERE ID=$id";
            $result = $con->query($sql);
            $row = $result->fetch_assoc();
            ?>
            <div class="form-container">
                <h2>Edit Product</h2>
        
                <form method="post" action="admin_home.php">
                    <input type="hidden" name="action" value="update">
                    <input type="hidden" name="id" value="<?php echo $row['ID']; ?>">
        
                    <div class="form-group">
                        <label for="name">Item Name:</label>
                        <input type="text" name="name" value="<?php echo $row['ITEM_NAME']; ?>" required>
                    </div>
        
                    <div class="form-group">
                        <label for="price">Price:</label>
                        <input type="number" name="price" value="<?php echo $row['ITEM_PRICE']; ?>" required>
                    </div>
        
                    <div class="form-group">
                        <label for="stock">Stock:</label>
                        <input type="number" name="stock" value="<?php echo $row['STOCK']; ?>" required>
                    </div>
        
                    <div class="form-group">
                        <label for="description">Description:</label>
                        <textarea name="description" required><?php echo $row['DESCRIPTION']; ?></textarea>
                    </div>
        
                    <div class="form-group">
                        <label for="specification">Specification:</label>
                        <textarea name="specification" required><?php echo $row['SPECIFICATION']; ?></textarea>
                    </div>
        
                    <div class="form-group">
                        <label for="image">Image URL:</label>
                        <input type="text" name="image" value="<?php echo $row['IMAGE']; ?>" required>
                    </div>
        
                    <input type="submit" value="Save Changes">
                </form>
            </div>
        <?php } else { ?>
            <div class="form-container">
                <h2>Add New Product</h2>
        
                <form method="post" action="admin_home.php">
                    <input type="hidden" name="action" value="create">
        
                    <div class="form-group">
                        <label for="name">Item Name:</label>
                        <input type="text" name="name" required>
                    </div>
        
                    <div class="form-group">
                        <label for="price">Price:</label>
                        <input type="number" name="price" required>
                    </div>
        
                    <div class="form-group">
                        <label for="stock">Stock:</label>
                        <input type="number" name="stock" required>
                    </div>
        
                    <div class="form-group">
                        <label for="description">Description:</label>
                        <textarea name="description" required></textarea>
                    </div>
        
                    <div class="form-group">
                        <label for="specification">Specification:</label>
                        <textarea name="specification" required></textarea>
                    </div>
        
                    <div class="form-group">
                        <label for="image">Image URL:</label>
                        <input type="text" name="image" required>
                    </div>
        
                    <input type="submit" value="Add Product">
                </form>
            </div>
        <?php } ?>
        </div>
    </div>

</body>

