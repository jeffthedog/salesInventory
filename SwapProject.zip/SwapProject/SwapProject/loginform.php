<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>User Login</title>
<style>
  body {
    font-family: Arial, sans-serif;
    background: #333;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
  }
  .login-container {
    background: #555;
    padding: 40px; 
    border-radius: 15px; 
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.5); 
    width: 300px; 
    color: #fff; 
  }
  .login-container h2 {
    text-align: center;
    margin-bottom: 20px; 
  }
  .login-form {
    display: flex;
    flex-direction: column;
  }
  .login-form input[type="text"],
  .login-form input[type="password"] {
    padding: 10px;
    margin-bottom: 10px;
    border: 1px solid #555; 
    border-radius: 5px;
    background: #ddd; 
  }
  .login-form input[type="submit"] {
    padding: 10px;
    margin-top: 20px; 
    border: none;
    border-radius: 5px;
    background: #5cb85c; 
    color: white;
    cursor: pointer;
  }
  .login-form input[type="submit"]:hover {
    background: #4cae4c; 
  }
  .login-options {
    text-align: center;
    margin-top: 15px; 
  }
  .login-options a {
    color: #999; 
    text-decoration: none;
    margin: 0 5px;
  }
</style>
</head>
<body>

<div class="login-container">
  <h2>User Login</h2>
  <form class="login-form" action="login.php" method="post">
    <input type="text" placeholder="Username" name="username" required>
    <input type="password" placeholder="Password" name="password" required>
    <input type="submit" value="Login">
  </form>
  <div class="login-options">
    <a href="admin_loginform.php">Admin Login</a>
   
<a href="registerform.php">Register</a>

  </div>
</div>
</body>
</html>