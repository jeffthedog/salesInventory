<?php
@session_start();
require_once 'database.php';
require_once "auth.php";

// Function to sanitize input
function sanitizeInput($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

// Check if the user is logged in
redirectToLogin();

// Check if the user has admin privileges
redirectToAccessDenied();

// Delete
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    $id = $_GET['id'];
    
    // Prepared statement for DELETE
    $stmt = $con->prepare("DELETE FROM user WHERE ID=?");
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        header("Location: usermanagement.php");
    } else {
        echo "Error deleting record: " . $stmt->error;
    }
}
?>


<?= admin_header('Admin_Home') ?>

<style>
    <style> 
        table {
            border-collapse: collapse;
            width: 100%;
        }
    
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
    
        th {
            background-color: #f2f2f2;
        }
    
        tr:hover {
            background-color: #f5f5f5;
        }
    
        /* Add your own styling for the dropdown button if needed */
        .dropdown-btn {
            padding: 5px 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }
    
        /* Hide the details row initially */
        .details-row {
            display: none;
        }
        
        .body {
            font-family: Arial, sans-serif;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
        }
        .nav {
            list-style-type: none;
            display: flex;
            gap: 20px;
        }
        .nav li {
            display: inline;
        }
        .search-bar {
            display: flex;
            gap: 10px;
        }
        .search-bar input {
            padding: 5px;
        }
        .sidebar {
            float: left;
            width: 20%;
            height: 100vh;
            background-color: #f0f0f0;
            padding: 20px;
        }
        .content {
            float: right;
            width: 80%;
            height: 100vh;
            background-color: #fff;
            padding: 20px;
        }
        .sidebar ul {
            list-style-type: none;
            padding: 0;
        }
        .sidebar li {
            margin-bottom: 10px;
            cursor: pointer; /* Add this line to make the items clickable */
        }
        /* Clear floats after the columns */
        .row:after {
            content: "";
            display: table;
            clear: both;
        }
     
        input, textarea, select { 
            width: 100%; 
            padding: 8px; 
            box-sizing: border-box; 
            margin-bottom: 10px; 
        } 
     
        input[type="submit"] { 
            background-color: #4CAF50; 
            color: white; 
            cursor: pointer; 
        } 
    </style>
    
    
</style>

<div class="row">
    <div class="sidebar">
        <ul>
            <li><a href="sales_chart.php">Sales</a></li>
            <li><a href="transactions.php">Transactions</a></li>
            <li><a href="usermanagement.php">Users</a></li>
            <li><a href="admin_home.php">Products</a></li>
        </ul>
    </div>

    <div class="content">
        <h1>User List</h1>

        <table>
            <tr>
                <th>Name</th>
                <th>Username</th>
                <th>Password</th>
                <th>Address</th>
                <th>Email</th>
                <th>Contact</th>
                <th>Role</th>
                <th>Action</th>
            </tr>

            <?php
            $sql = "SELECT * FROM user";
            $result = $con->query($sql);

            while ($row = $result->fetch_assoc()) {
            ?>
                <tr>
                    <td><?php echo sanitizeInput($row['NAME']); ?></td>
                    <td><?php echo sanitizeInput($row['USERNAME']); ?></td>
                    <td><?php echo sanitizeInput($row['PASSWORD']); ?></td>
                    <td><?php echo sanitizeInput($row['ADDRESS']); ?></td>
                    <td><?php echo sanitizeInput($row['EMAIL']); ?></td>
                    <td><?php echo sanitizeInput($row['CONTACT']); ?></td>
                    <td><?php echo sanitizeInput($row['ROLE']); ?></td>
                    <td>
                        <a href="usermanagement.php?action=delete&id=<?php echo $row['ID']; ?>"
                            onclick="return confirm('Are you sure?')">Delete</a>
                    </td>
                </tr>
            <?php } ?>

        </table>
    </div>
</div>


<!-- //finalcode -->