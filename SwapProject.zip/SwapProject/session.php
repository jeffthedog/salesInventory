<?php

$session_lifetime = 50; // Set to 10 seconds for your project

if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $session_lifetime)) {
    // Session has expired
    session_unset(); // Unset $_SESSION variable for the run-time
    session_destroy(); // Destroy session data in storage
    header('Location: session_expired.php'); // Redirect to the session expired message page
    exit;
}
$_SESSION['last_activity'] = time(); // Update last activity timestamp
?>