<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Incorrect Credentials</title>
    <style>
        body {
            background-color: #fff; 
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Arial', sans-serif;
        }
        .message-box {
            background-color: #23272A; 
            padding: 20px 40px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.5); 
            text-align: center;
            color: #FFFFFF; 
            max-width: 300px; 
        }
        .error-message {
            margin-bottom: 16px; 
            font-size: 18px; 
        }
        .message-box a {
            display: inline-block;
            background-color: #5865F2; 
            color: #FFFFFF; 
            padding: 10px 20px;
            border-radius: 4px;
            text-decoration: none; 
            transition: background-color 0.2s; 
            margin-top: 8px; 
            font-size: 16px; 
        }
        .message-box a:hover {
            background-color: #4752c4; 
        }
    </style>
</head>
<body>

<div class="message-box">
    <?php
    // Show the user the correct message
    if (isset($_GET['error'])) {
        switch ($_GET['error']) {
            case 'accessdenied':
                echo "<p class='error-message'>Access denied: unauthorized user.</p>";
                break;
            case 'wrongpassword':
                echo "<p class='error-message'>The password you entered was not valid.</p>";
                break;
            case 'usernamenotfound':
                echo "<p class='error-message'>No account found with that username.</p>";
                break;
            
        }
    }
    ?>
    <a href="loginform.php">Return to Login Page</a>
</div>

</body>
</html>