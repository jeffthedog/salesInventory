

<?php
include 'database.php';
// Start the session
session_start();

// Check if the logout has been confirmed
if (isset($_GET['confirmed']) && $_GET['confirmed'] == 'yes') {
    // Clear session variables that hold user information
    $_SESSION = array();

    // If it's desired to kill the session, also delete the session cookie
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }

    // Finally, destroy the session
    session_destroy();

    // Redirect to the home page after logout
    header('Location: index.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Logout</title>
<style>
body {
.logout-link {
    position: absolute; /* or use 'fixed' if you want it to stay in place when scrolling */
    top: 0;
    right: 0;
    padding: 10px; /* Adjust the padding to move the link inward from the corner */
}

#logout {
    color: #fff;
    background-color: #000; /* Match this color to your theme */
   
padding: 5px 15px;
text-decoration: none;
border-radius: 5px;
font-weight: bold;
}

#logout:hover {
background-color: #444; /* Change as needed for hover effect */
}
body {
  font-family: 'Arial', sans-serif;
  margin: 0;
  padding: 0;
  background-color: #f4f4f4; /* Assuming the blurred background color */
}


#logout {
    color: #fff;
    background-color: #000; /* Adjust the color to match your theme */
    padding: 10px 20px;
    text-decoration: none;
    border-radius: 5px;
    font-weight: bold;
    transition: background-color 0.3s ease;
}

#logout:hover {
    background-color: #444; /* Darken the button on hover */
}

.logout-container {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  padding: 20px;
  box-sizing: border-box;
}

.logout-dialog {
  background-color: #333; /* Dark background of the modal */
  color: white;
  padding: 20px;
  border-radius: 8px;
  width: 300px;
  box-shadow: 0 4px 8px rgba(0,0,0,0.1);
  text-align: center;
}

.logout-dialog h2 {
 
margin-top: 0;
}

.actions {
margin-top: 20px;
}

button {
background-color: #ffc107; /* Yellow color for buttons */
border: none;
padding: 10px 20px;
margin: 0 10px;
border-radius: 5px;
cursor: pointer;
font-weight: bold;
}

button:hover {
opacity: 0.8;
}
</style>
</head>
<body>
<div class="logout-container">
  <div class="logout-dialog">
    <h2>Logout</h2>
    <p>Are you sure you want to logout?</p>
    <div class="actions">
      <!-- Update the Yes button to include confirmed=yes query parameter -->
      <button onclick
="window.location.href='?confirmed=yes'">Yes</button>
<button onclick="history.back()">No</button>
</div>

  </div>
</div>
</body>
</html>