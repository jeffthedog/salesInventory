<?php
session_start();
require_once 'GoogleAuthenticator-master/PHPGangsta/GoogleAuthenticator.php'; // Library for QR code

// Generates a secret key
function generateSecretKey() {
    $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $secretKey = '';
    
    // Generate a key that consist of 20 characters
    for ($i = 0; $i < 20; $i++) {
        $secretKey .= $characters[random_int(0, strlen($characters) - 1)];
    }
    
    return $secretKey;
}

// check the secret key
if (!isset($_SESSION['2fa_secret'])) {
    $secretKey = generateSecretKey();
    $_SESSION['2fa_secret'] = $secretKey;
}

$secretKey = $_SESSION['2fa_secret'];

// Create an instance of GoogleAuthenticator
$ga = new PHPGangsta_GoogleAuthenticator();

// Function to verify TOTP Code
function verifyTOTPCode($secretKey, $code) {
    global $ga;
    $isCodeValid = $ga->verifyCode($secretKey, $code, 1); // 1 is the acceptable time drift (adjust as needed)
    return $isCodeValid;
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['2fa_code'])) {
        $code = $_POST['2fa_code'];
        
        // Verify the TOTP code
        if (verifyTOTPCode($secretKey, $code)) {
            $_SESSION['loggedin'] = true;
            header("Location: index.php");
            exit;
        } else {
            $error = "Invalid 2FA code. Please try again.";
        }
    }
}


$userDisplayName = 'User';


$displayName = "{$userDisplayName} "; // Create a display name that shows the user's name and issuer

$encodedDisplayName = urlencode($displayName); //

// Create URL for the code
$qrCodeUrl = $ga->getQRCodeGoogleUrl($encodedDisplayName, $secretKey, 'Mango Pomelo'); // Replace 'Mango Pomelo' with your app or company name.

?>

<!DOCTYPE html>
<html>
<head>
    <title>2FA Verification</title>
    <style>
        body {
            background-color: #fff; 
            font-family: Arial, sans-serif; 
            color: white; 
        }

    form {
        background-color: #fff; 
        border-radius: 5px; 
        padding: 20px; 
        width: 300px; 
        margin: 100px auto; 
        box-shadow: 0 0 10px rgba(0,0,0,0.5); 
    }

    label {
        color: #333; 
        display: block; 
        margin-bottom: 5px; 
    }

    input[type="text"],
    input[type="password"] {
        border: 1px solid #ddd; 
        border-radius: 3px; 
        padding: 10px; 
        width: 100%; 
        box-sizing: border-box; 
        margin-bottom: 20px; 
    }

    input[type="submit"] {
        background-color: #4CAF50; 
        color: white; 
        border: none; 
        padding: 15px 20px; 
        text-transform: uppercase; /
        font-weight: bold; 
        cursor: pointer; 
        width: 100%; 
        display: block; 
        border-radius: 5px; 
}


    input[type="submit"]:hover {
        background-color: #45a049; 
    }

    .error {
        color: #FF0000; 
        margin-bottom: 20px; 
    }

    img {
        display: block; 
        margin: 20px auto; 
        max-width: 100%; 
        height: auto; 
    }
</style>
</head>
<body>
    <?php if (isset($error)): ?>
    <p class="error"><?php echo $error; ?></p>
    <?php endif; ?>

<form action="2fa_check.php" method="post">
    <label for="2fa_code">Enter your 2FA code:</label>
    <input type="text" id="2fa_code" name="2fa_code" required>
    <input type="submit" value="Verify">
</form>

<?php if (isset($qrCodeUrl)): ?>
<img src="<?php echo htmlspecialchars($qrCodeUrl); ?>" alt="2FA QR Code" />
<?php else: ?>
<p>QR code URL is missing or invalid.</p>
<?php endif; ?>
</body>
</html>