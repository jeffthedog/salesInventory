<?php
require_once "database.php";

function sanitizeData($data) { //Sanitize user data
    return htmlspecialchars(stripslashes(trim($data)));
}


if ($_SERVER["REQUEST_METHOD"] == "POST") { // Check if the login form was submitted
    $username = sanitizeData($_POST['username']);
    $password = sanitizeData($_POST['password']);
    
    
    if ($username !== "admin") { // Check if the username is "admin"
        
        header("Location: wrongcredentialsadmin.php?error=accessdenied"); // Redirect users to wrong credentials if user is not admin.
        exit;
    } else {
        // SQL statement to prevent injection
        $stmt = $con->prepare("SELECT id, USERNAME, PASSWORD, SECRET FROM user WHERE USERNAME = ?");
        $stmt->bind_param("s", $username);
        
        if ($stmt->execute()) {
            $stmt->store_result();
            
            if ($stmt->num_rows == 1) { // Check if the username exists
                $stmt->bind_result($id, $fetched_username, $hashed_password, $secretKey);
                if ($stmt->fetch()) {
                    if (password_verify($password, $hashed_password)) { // Verify the password with the hash password.
                        session_start();
                        $_SESSION['loggedin'] = true;
                        $_SESSION['id'] = $id;
                        $_SESSION['username'] = $fetched_username;
                        
                        if (!empty($secretKey)) {
                            $_SESSION['2fa_id'] = $id;
                            $_SESSION['2fa_secret'] = $secretKey;
                            header("Location: 2fa_checkadmin.php"); // directs user to the 2fa check
                        } else {
                            header("Location: admin_home.php"); // After successfully authenticating direct user to admin home page
                        }
                        exit;
                    } else {
                        header("Location: wrongcredentialsadmin.php?error=wrongpassword"); // Password is incorrect
                        exit;
                    }
                }
            } else {
                
                header("Location: wrongcredentialsadmin.php?error=usernamenotfound"); // Username doesn't exist
                exit;
            }
            
            $stmt->close();
        }else {
            echo "Oops! Something went wrong. Please try again later.";
        }
        
        $con->close();
    }
}
?>