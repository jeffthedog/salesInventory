<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Error</title>
    <style>
        body {
            background-color: #fff; 
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Arial', sans-serif;
        }

        .message-container {
            background-color: #23272A; 
            padding: 20px 30px;
            border-radius: 5px; 
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.5); 
            text-align: center;
            width: auto;
            max-width: 80%;
        }

        /* Style the error message */
        .error-message {
            color: #ffffff; 
            margin-bottom: 20px; 
            font-size: 18px; 
        }

        /* Style the navigation link */
        a {
            color: #ffffff; 
            background-color: #5865F2; 
            padding: 10px 20px;
            border-radius: 4px; 
            text-decoration: none; 
            display: inline-block; 
            transition: background-color 0.3s ease; 
            font-size: 16px; 
            margin-top: 10px; 
        }

        a:hover {
            background-color: #4752c4; 
            text-decoration: none; 
        }
    </style>
</head>
<body>

<div class="message-container">
    <?php
    if (isset($_GET['error'])) {
        if ($_GET['error'] == 'username') {
            echo "<p class='error-message'>No account found with that username.</p>";
        } elseif ($_GET['error'] == 'password') {
            echo "<p class='error-message'>The password you entered was not valid.</p>";
        }
    }
    ?>
    <a href="loginform.php">Return to Login Page</a>
</div>

</body>
</html>