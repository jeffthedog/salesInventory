<?php
// Assuming $con is a valid MySQLi connection
$stmt = $con->prepare('SELECT * FROM item');
$stmt->execute();

// Get the result set from the query
$result = $stmt->get_result();

// Fetch the products from the result set and return the result as an array
$products = $result->fetch_all(MYSQLI_ASSOC);

// Get the number of rows
$total_products = $result->num_rows;

// Close the statement
$stmt->close();
?>

<?=website_header('Products')?>

<div class="products content-wrapper">
    <h1>Products</h1>
    <p><?=$total_products?> Products</p>
    <div class="products-wrapper">
        <?php foreach ($products as $product): ?>
        <a href="index.php?page=product&id=<?=$product['ID']?>" class="product">
            <img src="<?=$product['IMAGE']?>" width="200" height="200" alt="<?=$product['ITEM_NAME']?>">
            <span class="name"><?=$product['ITEM_NAME']?></span>
            <span class="price">
                &dollar;<?=$product['ITEM_PRICE']?>
            </span>
        </a>
        <?php endforeach; ?>
    </div>

</div>

<?=website_footer()?>

