<?php
// Assuming $con is a valid MySQLi connection
$stmt = $con->prepare('SELECT * FROM item');
$stmt->execute();

// Binding result variables
$stmt->bind_result($id, $item_name, $item_price, $stock, $description, $specification, $image);

// Fetching results into an array
$products = array();

while ($stmt->fetch()) {
    $product = array(
        'ID' => $id,
        'ITEM_NAME' => $item_name,
        'ITEM_PRICE' => $item_price,
        'IMAGE' => $image,
        // Add more columns as needed
    );
    $products[] = $product;
}

// Close the statement
$stmt->close();
?>

<?=website_header('Home')?>

<div class="featured">
    <h2>Safety Equipment</h2>
    <p>Essential Safety Equipment for your protection</p>
</div>
<div class="recentlyadded content-wrapper">
    <h2>Recently Added Products</h2>
    <div class="products">
        <?php foreach ($products as $product): ?>
        <a href="index.php?page=product&id=<?=$product['ID']?>" class="product">
            <img src="<?=$product['IMAGE']?>" width="200" height="200" alt="<?=$product['ITEM_NAME']?>">
            <span class="name"><?=$product['ITEM_NAME']?></span>
            <span class="price">
                &dollar;<?=$product['ITEM_PRICE']?>
            </span>
        </a>
        <?php endforeach; ?>
    </div>
</div>

<?=website_footer()?>
