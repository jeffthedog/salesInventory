<?php
@session_start();
require_once 'database.php';
require_once "auth.php";
// Check if the user is logged in
redirectToLogin();

// Check if the user has admin privileges
redirectToAccessDenied();

// Function to sanitize input
function sanitizeInput($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

// Function to validate and sanitize email
function validateAndSanitizeEmail($email) {
    $sanitizedEmail = filter_var($email, FILTER_VALIDATE_EMAIL);
    return $sanitizedEmail ? sanitizeInput($sanitizedEmail) : null;
}



// Create
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action'])) {
    if ($_POST['action'] == 'create') {
        $name = $_POST['name'];
        $username = $_POST['username'];
        $password = $_POST['password'];
        $address = $_POST['address'];
        $email = $_POST['email'];
        $contact = $_POST['contact'];
        $role = $_POST['role'];
        
        // Prepared statement for INSERT
        $stmt = $con->prepare("INSERT INTO user (NAME, USERNAME, PASSWORD, ADDRESS, EMAIL, CONTACT, ROLE) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssss", $name, $username, $password, $address, $email, $contact, $role);
        
        if ($stmt->execute()) {
            header("Location: usermanagement.php");
        } else {
            echo "Error: " . $stmt->error;
        }
    }
}


// Read
$sql = "SELECT * FROM user";
$result = $con->query($sql);

// Update
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action']) && $_POST['action'] == 'update') {
    // CSRF Protection: Check if the CSRF token is valid
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        // Handle CSRF token mismatch
        header("Location: csrf_error.php");
        exit();
    }
    
    // Validate and sanitize inputs
    $id = sanitizeInput($_POST['id']);
    $name = sanitizeInput($_POST['name']);
    $username = sanitizeInput($_POST['username']);
    $password = sanitizeInput($_POST['password']);
    $address = sanitizeInput($_POST['address']);
    $email = validateAndSanitizeEmail($_POST['email']);
    $contact = sanitizeInput($_POST['contact']);
    $role = sanitizeInput($_POST['role']);
    
    // Prepared statement for UPDATE
    $stmt = $con->prepare("UPDATE user SET NAME=?, USERNAME=?, PASSWORD=?, ADDRESS=?, EMAIL=?, CONTACT=?, ROLE=? WHERE ID=?");
    $stmt->bind_param("sssssssi", $name, $username, $password, $address, $email, $contact, $role, $id);
    
    if ($stmt->execute()) {
        header("Location: usermanagement.php");
    } else {
        echo "Error updating record: " . $stmt->error;
    }
}


// Delete
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    $id = $_GET['id'];
    
    // Prepared statement for DELETE
    $stmt = $con->prepare("DELETE FROM user WHERE ID=?");
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        header("Location: usermanagement.php");
    } else {
        echo "Error deleting record: " . $stmt->error;
    }
}

?>
<?=admin_header('Admin_Home')?>

    <style> 
        table {
            border-collapse: collapse;
            width: 100%;
        }
    
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
    
        th {
            background-color: #f2f2f2;
        }
    
        tr:hover {
            background-color: #f5f5f5;
        }
    
        /* Add your own styling for the dropdown button if needed */
        .dropdown-btn {
            padding: 5px 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }
    
        /* Hide the details row initially */
        .details-row {
            display: none;
        }
        
        .body {
            font-family: Arial, sans-serif;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
        }
        .nav {
            list-style-type: none;
            display: flex;
            gap: 20px;
        }
        .nav li {
            display: inline;
        }
        .search-bar {
            display: flex;
            gap: 10px;
        }
        .search-bar input {
            padding: 5px;
        }
        .sidebar {
            float: left;
            width: 20%;
            height: 100vh;
            background-color: #f0f0f0;
            padding: 20px;
        }
        .content {
            float: right;
            width: 80%;
            height: 100vh;
            background-color: #fff;
            padding: 20px;
        }
        .sidebar ul {
            list-style-type: none;
            padding: 0;
        }
        .sidebar li {
            margin-bottom: 10px;
            cursor: pointer; /* Add this line to make the items clickable */
        }
        /* Clear floats after the columns */
        .row:after {
            content: "";
            display: table;
            clear: both;
        }
     
        input, textarea, select { 
            width: 100%; 
            padding: 8px; 
            box-sizing: border-box; 
            margin-bottom: 10px; 
        } 
     
        input[type="submit"] { 
            background-color: #4CAF50; 
            color: white; 
            cursor: pointer; 
        } 
    </style>
    

    <div class="row">
        <div class="sidebar">
            <ul>
                <li><a href="sales_chart.php">Sales</a></li>
            	<li><a href="transactions.php">Transactions</a></li>
                <li><a href="usermanagement.php">Users</a></li>
                <li><a href="admin_home.php">Products</a></li>
            </ul>
        </div>
<div class="content">
           <h1>User List</h1>
            
            <table>
                <tr>
                    <th>Name</th>
                    <th>Username</th>
                    <th>Password</th>
                    <th>Address</th>
                    <th>Email</th>
                    <th>Contact</th>
                    <th>Role</th>
                    <th>Action</th>
                </tr>
            
                <?php while($row = $result->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo sanitizeInput($row['NAME']); ?></td>
                        <td><?php echo sanitizeInput($row['USERNAME']); ?></td>
                        <td><?php echo sanitizeInput($row['PASSWORD']); ?></td>
                        <td><?php echo sanitizeInput($row['ADDRESS']); ?></td>
                        <td><?php echo sanitizeInput($row['EMAIL']); ?></td>
                        <td><?php echo sanitizeInput($row['CONTACT']); ?></td>
                        <td><?php echo sanitizeInput($row['ROLE']); ?></td>
                        <td>
                            <a href="usermanagement.php?action=update&id=<?php echo $row['ID']; ?>">Edit</a>
                            <a href="usermanagement.php?action=delete&id=<?php echo $row['ID']; ?>" onclick="return confirm('Are you sure?')">Delete</a>
                        </td>
                    </tr>
                <?php } ?>
                
            </table>
            
            <?php
            if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['action']) && $_GET['action'] == 'update' && isset($_GET['id'])) {
                $id = $_GET['id'];
                $sql = "SELECT * FROM user WHERE ID=?";
                $stmt = $con->prepare($sql);
                $stmt->bind_param("i", $id);
                $stmt->execute();
                $result = $stmt->get_result();
                $row = $result->fetch_assoc();
                ?>
                <div class="form-container">
                    <h2>Edit User</h2>
            
                    <form method="post" action="usermanagement.php">
                        <!-- CSRF Protection: Include CSRF token in the form -->
                        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                        <input type="hidden" name="action" value="update">
                        <input type="hidden" name="id" value="<?php echo $row['ID']; ?>">
            
                        <div class="form-group">
                            <label for="name">Name:</label>
                            <input type="text" name="name" value="<?php echo sanitizeInput($row['NAME']); ?>" required>
                        </div>
            
                        <div class="form-group">
                            <label for="username">Username:</label>
                            <input type="text" name="username" value="<?php echo sanitizeInput($row['USERNAME']); ?>" required>
                        </div>
            
                        <div class="form-group">
                            <label for="password">Password:</label>
                            <input type="password" name="password" required>
                        </div>
            
                        <div class="form-group">
                            <label for="address">Address:</label>
                            <input type="text" name="address" value="<?php echo sanitizeInput($row['ADDRESS']); ?>" required>
                        </div>
            
                        <div class="form-group">
                            <label for="email">Email:</label>
                            <input type="email" name="email" value="<?php echo sanitizeInput($row['EMAIL']); ?>" required>
                        </div>
            
                        <div class="form-group">
                            <label for="contact">Contact:</label>
                            <input type="text" name="contact" value="<?php echo sanitizeInput($row['CONTACT']); ?>" required>
                        </div>
            
                        <div class="form-group">
                            <label for="role">Role:</label>
                            <select name="role" required>
                                <option value="user" <?php echo ($row['ROLE'] == 'user') ? 'selected' : ''; ?>>User</option>
                                <option value="admin" <?php echo ($row['ROLE'] == 'admin') ? 'selected' : ''; ?>>Admin</option>
                            </select>
                        </div>
            
                        <input type="submit" value="Save Changes">
                    </form>
                </div>
            <?php } ?>
        </div>
    </div>
</body>
</html>


