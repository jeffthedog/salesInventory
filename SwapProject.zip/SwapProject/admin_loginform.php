<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Administrator Login</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background: #fff;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        margin: 0;
    }

    .login-container {
        background: #555; 
        padding: 40px;
        border-radius: 15px;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.5);
        width: 300px; 
    }

    .login-container h2 {
        color: #fff;
        text-align: center;
        margin-bottom: 20px;
    }

    .login-form {
        display: flex;
        flex-direction: column;
    }

    .login-form input[type="text"],
    .login-form input[type="password"] {
        padding: 10px;
        margin-bottom: 10px;
        border: 1px solid #555;
        border-radius: 5px;
        background: #ddd; 
    }

    .login-form input[type="submit"] {
        padding: 10px;
        margin-top: 20px;
        border: none;
        border-radius: 5px;
        background: #5cb85c; 
        color: white;
        cursor: pointer;
        font-weight: bold; 
    }

    .login-form input[type="submit"]:hover {
        background: #4cae4c; 
    }

    .back-link {
        color: #ccc;
        text-align: center;
        display: block;
        margin-top: 15px;
        text-decoration: none;
        font-weight: bold; 
    }

    .back-link:hover {
        color: #fff;
        text-decoration: underline;
    }

    .icon-user
{
background: url('icon-user.png') no-repeat center center;
background-size: cover;
display: block;
width: 80px;
height: 80px;
margin: 20px auto; 
}

</style>
</head>
<body>
<div class="login-container">
    <div class="icon-user"></div>
    <h2>Administrator Login</h2>
    <form class="login-form" action="admin_login.php" method="post">
        <input type="text" name="username" placeholder="Username" required>
        <input type="password" name="password" placeholder="Password" required>
        <input type="submit" value="Login">
    </form>
    <a href="loginform.php" class="back-link">Back to login</a>
</div>
</body>
</html>